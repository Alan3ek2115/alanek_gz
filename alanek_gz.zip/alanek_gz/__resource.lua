resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

dependency "dopeNotifyV2"
config_script "config.lua"
config_script "api-ac_teMGkbDylFhs.lua"
config_script "api-ac_JsIRquObnNEK.lua"
config_script "api-ac_EHvSnzeIVezq.lua"
config_script "api-ac_cGMHaaLMfhMa.lua"
config_script "api-ac_XVzIWfbsNyHG.lua"

--by.alanek